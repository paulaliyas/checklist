import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { combineLatest, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  ChecklistTemplate,
  ItemProgress,
  StageTemplate,
  StepStatus,
  StepTemplate,
  TrackedItem
} from '../core/models';
import { fillText, getProgress } from '../core/progress.util';
import { StoreService } from '../core/store.service';
import { UserService } from '../core/user.service';

interface StepVm {
  step: StepTemplate;
  number: string;
  title: string;
  status: StepStatus | null;
  isNext: boolean;
  ref: string;
  mailText: string | null;
}

interface GroupVm {
  stage: StageTemplate;
  done: number;
  total: number;
  steps: StepVm[];
}

interface ChecklistVm {
  state: 'loading' | 'missing' | 'ready';
  item: TrackedItem | null;
  template: ChecklistTemplate | null;
  progress: ItemProgress | null;
  nextTitle: string;
  groups: GroupVm[];
}

@Component({
  selector: 'app-checklist',
  templateUrl: './checklist.component.html',
  styleUrls: ['./checklist.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChecklistComponent implements OnInit {
  vm$!: Observable<ChecklistVm>;
  openMailId: string | null = null;
  copiedId: string | null = null;
  confirmDelete = false;

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly store: StoreService,
    private readonly user: UserService,
    private readonly cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.vm$ = combineLatest([
      this.route.paramMap,
      this.store.items$,
      this.store.templates$,
      this.store.loaded$
    ]).pipe(map(([params, items, templates, loaded]) => this.buildVm(params.get('id'), items, templates, loaded)));
  }

  toggle(item: TrackedItem, step: StepTemplate, checked: boolean): void {
    this.store.update(item.id, { by: this.user.name, done: { [step.id]: checked } }).subscribe({ error: () => undefined });
  }

  saveRef(item: TrackedItem, step: StepTemplate, value: string): void {
    if ((item.refs[step.id] ?? '') === value.trim()) {
      return;
    }
    this.store.update(item.id, { by: this.user.name, refs: { [step.id]: value } }).subscribe({ error: () => undefined });
  }

  setTarget(item: TrackedItem, target: string): void {
    this.store.update(item.id, { by: this.user.name, target }).subscribe({ error: () => undefined });
  }

  remove(item: TrackedItem): void {
    this.store.remove(item.id).subscribe({
      next: () => void this.router.navigate(['/']),
      error: () => undefined
    });
  }

  toggleMail(stepId: string): void {
    this.openMailId = this.openMailId === stepId ? null : stepId;
  }

  copyMail(step: StepVm): void {
    const text = step.mailText ?? '';
    const done = (): void => {
      this.copiedId = step.step.id;
      this.cdr.markForCheck();
      setTimeout(() => {
        this.copiedId = null;
        this.cdr.markForCheck();
      }, 1500);
    };
    // navigator.clipboard only exists on https or localhost, so fall back for plain http on the network.
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, () => this.copyWithTextarea(text, done, step.step.id));
    } else {
      this.copyWithTextarea(text, done, step.step.id);
    }
  }

  trackGroup(_index: number, group: GroupVm): string {
    return group.stage.id;
  }

  trackStep(_index: number, step: StepVm): string {
    return step.step.id;
  }

  private copyWithTextarea(text: string, done: () => void, stepId: string): void {
    const area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', '');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    let ok = false;
    try {
      ok = document.execCommand('copy');
    } catch {
      ok = false;
    }
    document.body.removeChild(area);
    if (ok) {
      done();
    } else {
      // Could not copy: show the mail so it can be selected by hand.
      this.openMailId = stepId;
      this.cdr.markForCheck();
    }
  }

  private buildVm(
    id: string | null,
    items: TrackedItem[],
    templates: ChecklistTemplate[],
    loaded: boolean
  ): ChecklistVm {
    const empty: ChecklistVm = { state: 'loading', item: null, template: null, progress: null, nextTitle: '', groups: [] };
    const item = items.find(i => i.id === id);
    if (!item) {
      return { ...empty, state: loaded ? 'missing' : 'loading' };
    }
    const template = templates.find(t => t.id === item.templateId);
    if (!template) {
      return { ...empty, state: templates.length ? 'missing' : 'loading' };
    }

    const progress = getProgress(item, template);
    let count = 0;
    const groups: GroupVm[] = template.stages.map(stage => {
      const steps: StepVm[] = template.steps
        .filter(s => s.stage === stage.id)
        .map(step => {
          count++;
          return {
            step,
            number: String(count).padStart(2, '0'),
            title: fillText(step.title, item, template),
            status: item.done[step.id] ?? null,
            isNext: progress.nextStep?.id === step.id,
            ref: item.refs[step.id] ?? '',
            mailText: step.mail
              ? `To: ${step.mail.to}\nSubject: ${fillText(step.mail.subject, item, template)}\n\n${fillText(step.mail.body, item, template)}`
              : null
          };
        });
      return { stage, steps, done: steps.filter(s => !!s.status).length, total: steps.length };
    });

    return {
      state: 'ready',
      item,
      template,
      progress,
      nextTitle: progress.nextStep ? fillText(progress.nextStep.title, item, template) : '',
      groups
    };
  }
}
