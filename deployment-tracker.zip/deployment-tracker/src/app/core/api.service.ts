import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ChecklistTemplate, ItemChanges, NewItem, TrackedItem } from './models';

/** Talks to the shared server (server/server.js). */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly base = '/api';

  constructor(private readonly http: HttpClient) {}

  getTemplates(): Observable<ChecklistTemplate[]> {
    return this.http.get<ChecklistTemplate[]>(`${this.base}/templates`);
  }

  getItems(): Observable<TrackedItem[]> {
    return this.http.get<TrackedItem[]>(`${this.base}/items`);
  }

  createItem(item: NewItem): Observable<TrackedItem> {
    return this.http.post<TrackedItem>(`${this.base}/items`, item);
  }

  updateItem(id: string, changes: ItemChanges): Observable<TrackedItem> {
    return this.http.patch<TrackedItem>(`${this.base}/items/${id}`, changes);
  }

  deleteItem(id: string): Observable<{ id: string }> {
    return this.http.delete<{ id: string }>(`${this.base}/items/${id}`);
  }
}
