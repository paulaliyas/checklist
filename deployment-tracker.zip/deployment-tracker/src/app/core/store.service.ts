import { HttpErrorResponse } from '@angular/common/http';
import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { ApiService } from './api.service';
import { ChecklistTemplate, ItemChanges, NewItem, TrackedItem } from './models';

/**
 * Single source of truth for the screens.
 * Loads items from the server and reloads them whenever anyone on the network changes something.
 */
@Injectable({ providedIn: 'root' })
export class StoreService implements OnDestroy {
  private readonly itemsSubject = new BehaviorSubject<TrackedItem[]>([]);
  private readonly templatesSubject = new BehaviorSubject<ChecklistTemplate[]>([]);
  private readonly loadedSubject = new BehaviorSubject<boolean>(false);
  private readonly onlineSubject = new BehaviorSubject<boolean>(true);
  private readonly errorSubject = new BehaviorSubject<string | null>(null);
  private events: EventSource | null = null;
  private started = false;

  readonly items$: Observable<TrackedItem[]> = this.itemsSubject.asObservable();
  readonly templates$: Observable<ChecklistTemplate[]> = this.templatesSubject.asObservable();
  readonly loaded$: Observable<boolean> = this.loadedSubject.asObservable();
  readonly online$: Observable<boolean> = this.onlineSubject.asObservable();
  readonly error$: Observable<string | null> = this.errorSubject.asObservable();

  constructor(private readonly api: ApiService, private readonly zone: NgZone) {}

  /** Called once when the app starts. */
  init(): void {
    if (this.started) {
      return;
    }
    this.started = true;
    this.loadTemplates();
    this.refresh();
    this.listen();
  }

  refresh(): void {
    this.api.getItems().subscribe({
      next: items => {
        this.itemsSubject.next(items);
        this.loadedSubject.next(true);
      },
      error: (e: HttpErrorResponse) => this.report(e)
    });
  }

  create(item: NewItem): Observable<TrackedItem> {
    return this.api.createItem(item).pipe(
      tap(saved => this.upsert(saved)),
      catchError((e: HttpErrorResponse) => this.fail(e))
    );
  }

  update(id: string, changes: ItemChanges): Observable<TrackedItem> {
    return this.api.updateItem(id, changes).pipe(
      tap(saved => this.upsert(saved)),
      catchError((e: HttpErrorResponse) => this.fail(e))
    );
  }

  remove(id: string): Observable<{ id: string }> {
    return this.api.deleteItem(id).pipe(
      tap(() => this.itemsSubject.next(this.itemsSubject.value.filter(i => i.id !== id))),
      catchError((e: HttpErrorResponse) => this.fail(e))
    );
  }

  clearError(): void {
    this.errorSubject.next(null);
  }

  ngOnDestroy(): void {
    this.events?.close();
  }

  private loadTemplates(): void {
    this.api.getTemplates().subscribe({
      next: templates => this.templatesSubject.next(templates),
      error: (e: HttpErrorResponse) => this.report(e)
    });
  }

  /** Live updates: the server sends a "changed" event after every save. */
  private listen(): void {
    if (typeof EventSource === 'undefined') {
      return;
    }
    this.zone.runOutsideAngular(() => {
      const events = new EventSource('/api/events');
      this.events = events;
      events.addEventListener('changed', () => this.zone.run(() => this.refresh()));
      events.onopen = () =>
        this.zone.run(() => {
          if (!this.onlineSubject.value) {
            // Back after a drop: pick up anything missed.
            this.loadTemplates();
            this.refresh();
          }
          this.onlineSubject.next(true);
        });
      events.onerror = () => this.zone.run(() => this.onlineSubject.next(false));
    });
  }

  private upsert(saved: TrackedItem): void {
    const items = this.itemsSubject.value;
    const exists = items.some(i => i.id === saved.id);
    this.itemsSubject.next(exists ? items.map(i => (i.id === saved.id ? saved : i)) : [...items, saved]);
    this.errorSubject.next(null);
  }

  private fail(e: HttpErrorResponse): Observable<never> {
    this.report(e);
    this.refresh();
    return throwError(() => e);
  }

  private report(e: HttpErrorResponse): void {
    const message =
      e.status === 0
        ? 'Cannot reach the server. Your change was not saved.'
        : (e.error as { message?: string } | null)?.message ?? 'The server could not save that change.';
    this.errorSubject.next(message);
  }
}
