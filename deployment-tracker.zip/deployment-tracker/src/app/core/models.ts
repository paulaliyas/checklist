/** A checklist type, loaded from server/templates/*.json. */
export interface ChecklistTemplate {
  id: string;
  name: string;
  /** Optional choices for the {{target}} placeholder, e.g. release / hotfix. */
  targets?: string[];
  stages: StageTemplate[];
  steps: StepTemplate[];
}

export interface StageTemplate {
  id: string;
  name: string;
}

export interface StepTemplate {
  id: string;
  stage: string;
  title: string;
  /** Team that acts on this step, shown as a tag (QA, DevOps...). */
  owner?: string;
  /** When set, the step shows a text field with this label (MR link, Build no...). */
  refLabel?: string;
  mail?: MailTemplate;
}

export interface MailTemplate {
  to: string;
  subject: string;
  body: string;
}

export interface StepStatus {
  at: string;
  by: string;
}

/** One tracked story / feature, stored on the shared server. */
export interface TrackedItem {
  id: string;
  templateId: string;
  name: string;
  target: string;
  createdAt: string;
  createdBy: string;
  updatedAt: string;
  updatedBy: string;
  done: Record<string, StepStatus>;
  refs: Record<string, string>;
}

export interface NewItem {
  templateId: string;
  name: string;
  target: string;
  by: string;
}

export interface ItemChanges {
  by: string;
  target?: string;
  done?: Record<string, boolean>;
  refs?: Record<string, string>;
}

export type ItemStatus = 'Not started' | 'In progress' | 'Completed';

export interface StageProgress {
  stage: StageTemplate;
  done: number;
  total: number;
  state: 'done' | 'current' | 'todo';
}

export interface ItemProgress {
  done: number;
  total: number;
  percent: number;
  status: ItemStatus;
  nextStep: StepTemplate | null;
  currentStage: StageTemplate | null;
  stages: StageProgress[];
}
