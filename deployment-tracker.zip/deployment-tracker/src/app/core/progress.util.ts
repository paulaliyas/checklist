import { ChecklistTemplate, ItemProgress, StageProgress, StepTemplate, TrackedItem } from './models';

/** Works out how far an item is through its checklist. */
export function getProgress(item: TrackedItem, template: ChecklistTemplate): ItemProgress {
  const total = template.steps.length;
  const done = template.steps.filter((s: StepTemplate) => !!item.done[s.id]).length;
  const nextStep = template.steps.find((s: StepTemplate) => !item.done[s.id]) ?? null;
  const currentStage = nextStep ? template.stages.find(g => g.id === nextStep.stage) ?? null : null;

  const stages: StageProgress[] = template.stages.map(stage => {
    const steps = template.steps.filter(s => s.stage === stage.id);
    const stageDone = steps.filter(s => !!item.done[s.id]).length;
    const state: StageProgress['state'] =
      steps.length > 0 && stageDone === steps.length ? 'done' : currentStage?.id === stage.id ? 'current' : 'todo';
    return { stage, done: stageDone, total: steps.length, state };
  });

  return {
    done,
    total,
    percent: total ? Math.round((done / total) * 100) : 0,
    status: done === 0 ? 'Not started' : done === total ? 'Completed' : 'In progress',
    nextStep,
    currentStage,
    stages
  };
}

/**
 * Fills the placeholders used in template text:
 * {{name}}, {{target}} and {{ref:stepId}} (the value typed on that step).
 */
export function fillText(text: string, item: TrackedItem, template: ChecklistTemplate): string {
  return text.replace(/\{\{\s*(name|target|ref:([\w-]+))\s*\}\}/g, (_match: string, key: string, stepId?: string) => {
    if (key === 'name') {
      return item.name;
    }
    if (key === 'target') {
      return item.target;
    }
    const value = stepId ? item.refs[stepId] : '';
    if (value) {
      return value;
    }
    const label = template.steps.find(s => s.id === stepId)?.refLabel ?? 'value';
    return `<${label}>`;
  });
}
