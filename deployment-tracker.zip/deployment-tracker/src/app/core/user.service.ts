import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

const KEY = 'deployment-tracker-user';

/** Remembers who is using this browser, so changes show "done by". */
@Injectable({ providedIn: 'root' })
export class UserService {
  private readonly nameSubject = new BehaviorSubject<string>(this.read());
  readonly name$: Observable<string> = this.nameSubject.asObservable();

  get name(): string {
    return this.nameSubject.value;
  }

  setName(name: string): void {
    const clean = name.trim().slice(0, 60);
    this.nameSubject.next(clean);
    try {
      localStorage.setItem(KEY, clean);
    } catch {
      // Storage blocked: the name is kept for this visit only.
    }
  }

  private read(): string {
    try {
      return localStorage.getItem(KEY) ?? '';
    } catch {
      return '';
    }
  }
}
