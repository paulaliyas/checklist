import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { StoreService } from './core/store.service';
import { UserService } from './core/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit {
  readonly name$: Observable<string> = this.user.name$;
  readonly online$: Observable<boolean> = this.store.online$;
  readonly error$: Observable<string | null> = this.store.error$;

  constructor(private readonly store: StoreService, private readonly user: UserService) {}

  ngOnInit(): void {
    this.store.init();
  }

  onNameChange(value: string): void {
    this.user.setName(value);
  }

  dismissError(): void {
    this.store.clearError();
  }
}
