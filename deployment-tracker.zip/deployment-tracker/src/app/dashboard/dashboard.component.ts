import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { combineLatest, Observable, Subject } from 'rxjs';
import { map, startWith, takeUntil } from 'rxjs/operators';
import { ChecklistTemplate, ItemProgress, ItemStatus, TrackedItem } from '../core/models';
import { fillText, getProgress } from '../core/progress.util';
import { StoreService } from '../core/store.service';
import { UserService } from '../core/user.service';

interface Row {
  item: TrackedItem;
  template: ChecklistTemplate;
  progress: ItemProgress;
  nextTitle: string;
}

interface StageCount {
  key: string;
  name: string;
  count: number;
}

interface DashboardVm {
  loaded: boolean;
  templates: ChecklistTemplate[];
  rows: Row[];
  total: number;
  notStarted: number;
  inProgress: number;
  completed: number;
  stageCounts: StageCount[];
}

interface Filters {
  search: string;
  templateId: string;
  status: ItemStatus | '';
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent implements OnInit, OnDestroy {
  readonly statuses: ItemStatus[] = ['Not started', 'In progress', 'Completed'];
  readonly filterForm: FormGroup;
  readonly newForm: FormGroup;
  vm$!: Observable<DashboardVm>;
  targets: string[] = [];
  saving = false;

  private templates: ChecklistTemplate[] = [];
  private readonly destroy$ = new Subject<void>();

  constructor(
    private readonly fb: FormBuilder,
    private readonly store: StoreService,
    private readonly user: UserService,
    private readonly router: Router
  ) {
    this.filterForm = this.fb.group({ search: [''], templateId: [''], status: [''] });
    this.newForm = this.fb.group({
      templateId: ['', Validators.required],
      name: ['', [Validators.required, Validators.maxLength(120)]],
      target: ['']
    });
  }

  ngOnInit(): void {
    const filters$ = this.filterForm.valueChanges.pipe(startWith(this.filterForm.value)) as Observable<Filters>;

    this.vm$ = combineLatest([this.store.items$, this.store.templates$, this.store.loaded$, filters$]).pipe(
      map(([items, templates, loaded, filters]) => this.buildVm(items, templates, loaded, filters))
    );

    // Pick the first checklist type by default, and keep the target choices in step with it.
    this.store.templates$.pipe(takeUntil(this.destroy$)).subscribe(templates => {
      this.templates = templates;
      const current = this.newForm.get('templateId')?.value as string;
      if (templates.length && !templates.some(t => t.id === current)) {
        this.newForm.patchValue({ templateId: templates[0].id });
      } else {
        this.syncTargets(current);
      }
    });

    this.newForm
      .get('templateId')
      ?.valueChanges.pipe(takeUntil(this.destroy$))
      .subscribe((id: string) => this.syncTargets(id));
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  add(): void {
    if (this.newForm.invalid || this.saving) {
      this.newForm.markAllAsTouched();
      return;
    }
    const value = this.newForm.value as { templateId: string; name: string; target: string };
    this.saving = true;
    this.store
      .create({ templateId: value.templateId, name: value.name.trim(), target: value.target, by: this.user.name })
      .subscribe({
        next: item => {
          this.saving = false;
          this.newForm.patchValue({ name: '' });
          this.newForm.markAsUntouched();
          void this.router.navigate(['/items', item.id]);
        },
        error: () => {
          this.saving = false;
        }
      });
  }

  open(row: Row): void {
    void this.router.navigate(['/items', row.item.id]);
  }

  trackRow(_index: number, row: Row): string {
    return row.item.id;
  }

  trackStage(_index: number, stage: StageCount): string {
    return stage.key;
  }

  private syncTargets(templateId: string): void {
    this.targets = this.templates.find(t => t.id === templateId)?.targets ?? [];
    const target = this.newForm.get('target')?.value as string;
    if (!this.targets.includes(target)) {
      this.newForm.patchValue({ target: this.targets[0] ?? '' }, { emitEvent: false });
    }
  }

  private buildVm(
    items: TrackedItem[],
    templates: ChecklistTemplate[],
    loaded: boolean,
    filters: Filters
  ): DashboardVm {
    const all: Row[] = [];
    for (const item of items) {
      const template = templates.find(t => t.id === item.templateId);
      if (!template) {
        continue;
      }
      const progress = getProgress(item, template);
      all.push({
        item,
        template,
        progress,
        nextTitle: progress.nextStep ? fillText(progress.nextStep.title, item, template) : 'Done'
      });
    }
    all.sort((a, b) => b.item.updatedAt.localeCompare(a.item.updatedAt));

    // "Where things are": open items counted by the stage they are waiting in.
    const many = templates.length > 1;
    const stageCounts: StageCount[] = [];
    for (const template of templates) {
      for (const stage of template.stages) {
        stageCounts.push({
          key: `${template.id}:${stage.id}`,
          name: many ? `${template.name}: ${stage.name}` : stage.name,
          count: all.filter(r => r.template.id === template.id && r.progress.currentStage?.id === stage.id).length
        });
      }
    }

    const search = (filters.search ?? '').trim().toLowerCase();
    const rows = all.filter(
      r =>
        (!search || r.item.name.toLowerCase().includes(search)) &&
        (!filters.templateId || r.template.id === filters.templateId) &&
        (!filters.status || r.progress.status === filters.status)
    );

    return {
      loaded,
      templates,
      rows,
      total: all.length,
      notStarted: all.filter(r => r.progress.status === 'Not started').length,
      inProgress: all.filter(r => r.progress.status === 'In progress').length,
      completed: all.filter(r => r.progress.status === 'Completed').length,
      stageCounts
    };
  }
}
