/*
 * Shared server for the Deployment Tracker.
 * No npm packages needed: run with `node server/server.js`.
 * - Stores every item in server/data/items.json (one file, shared by all users)
 * - Reads checklist templates from server/templates/*.json
 * - Pushes live updates to every open browser (Server-Sent Events)
 * - Serves the built Angular app from dist/deployment-tracker
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = path.join(__dirname, '..');
const DIST = process.env.DIST_DIR || path.join(ROOT, 'dist', 'deployment-tracker');
const TEMPLATES_DIR = process.env.TEMPLATES_DIR || path.join(__dirname, 'templates');
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data', 'items.json');
const MAX_BODY = 100 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.ico': 'image/x-icon', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.txt': 'text/plain; charset=utf-8', '.map': 'application/json', '.woff2': 'font/woff2'
};

/* ---------- storage ---------- */
let items = [];
try {
  items = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  if (!Array.isArray(items)) { items = []; }
} catch (e) {
  if (e.code !== 'ENOENT') { console.error('Could not read ' + DATA_FILE + ': ' + e.message); process.exit(1); }
}

function save() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(items, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}

function loadTemplates() {
  const out = [];
  let files = [];
  try { files = fs.readdirSync(TEMPLATES_DIR).filter(f => f.endsWith('.json')).sort(); } catch (e) { return out; }
  for (const f of files) {
    try {
      const t = JSON.parse(fs.readFileSync(path.join(TEMPLATES_DIR, f), 'utf8'));
      if (t && typeof t.id === 'string' && Array.isArray(t.stages) && Array.isArray(t.steps)) { out.push(t); }
      else { console.warn('Skipped template ' + f + ': needs id, stages and steps'); }
    } catch (e) { console.warn('Skipped template ' + f + ': ' + e.message); }
  }
  return out;
}

/* ---------- live updates ---------- */
const clients = new Set();
function broadcast() {
  for (const res of clients) { res.write('event: changed\ndata: ' + Date.now() + '\n\n'); }
}
setInterval(() => { for (const res of clients) { res.write(': ping\n\n'); } }, 25000).unref();

/* ---------- helpers ---------- */
function send(res, status, body) {
  const text = body === undefined ? '' : JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(text);
}
function fail(res, status, message) { send(res, status, { message: message }); }
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > MAX_BODY) { reject(new Error('too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) { resolve({}); return; }
      try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(v && typeof v === 'object' ? v : {}); }
      catch (e) { reject(new Error('invalid JSON')); }
    });
    req.on('error', reject);
  });
}
const text = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const who = v => text(v, 60) || 'Unknown';

/* ---------- API ---------- */
async function api(req, res, url) {
  const parts = url.pathname.split('/').filter(Boolean); // ['api', 'items', ':id']
  const method = req.method;

  if (parts[1] === 'templates' && method === 'GET') { return send(res, 200, loadTemplates()); }

  if (parts[1] === 'events' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write('retry: 3000\n\n');
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }

  if (parts[1] !== 'items') { return fail(res, 404, 'Not found'); }

  if (parts.length === 2 && method === 'GET') { return send(res, 200, items); }

  if (parts.length === 2 && method === 'POST') {
    const b = await readBody(req);
    const template = loadTemplates().find(t => t.id === b.templateId);
    const name = text(b.name, 120);
    if (!template) { return fail(res, 400, 'Unknown checklist type'); }
    if (!name) { return fail(res, 400, 'Name is required'); }
    const targets = Array.isArray(template.targets) ? template.targets : [];
    const now = new Date().toISOString();
    const item = {
      id: crypto.randomBytes(6).toString('hex'), templateId: template.id, name: name,
      target: targets.includes(b.target) ? b.target : (targets[0] || ''),
      createdAt: now, createdBy: who(b.by), updatedAt: now, updatedBy: who(b.by), done: {}, refs: {}
    };
    items.push(item); save(); broadcast();
    return send(res, 201, item);
  }

  const item = items.find(i => i.id === parts[2]);
  if (parts.length !== 3) { return fail(res, 404, 'Not found'); }
  if (!item) { return fail(res, 404, 'This item no longer exists'); }

  if (method === 'PATCH') {
    const b = await readBody(req);
    const template = loadTemplates().find(t => t.id === item.templateId);
    const stepIds = new Set(template ? template.steps.map(s => s.id) : []);
    const now = new Date().toISOString();
    if (typeof b.name === 'string' && text(b.name, 120)) { item.name = text(b.name, 120); }
    if (typeof b.target === 'string' && template && Array.isArray(template.targets) && template.targets.includes(b.target)) { item.target = b.target; }
    if (b.done && typeof b.done === 'object') {
      for (const id of Object.keys(b.done)) {
        if (!stepIds.has(id)) { continue; }
        if (b.done[id]) { if (!item.done[id]) { item.done[id] = { at: now, by: who(b.by) }; } }
        else { delete item.done[id]; }
      }
    }
    if (b.refs && typeof b.refs === 'object') {
      for (const id of Object.keys(b.refs)) {
        if (!stepIds.has(id)) { continue; }
        const v = text(b.refs[id], 300);
        if (v) { item.refs[id] = v; } else { delete item.refs[id]; }
      }
    }
    item.updatedAt = now; item.updatedBy = who(b.by);
    save(); broadcast();
    return send(res, 200, item);
  }

  if (method === 'DELETE') {
    items = items.filter(i => i.id !== item.id); save(); broadcast();
    return send(res, 200, { id: item.id });
  }

  return fail(res, 405, 'Method not allowed');
}

/* ---------- static files (the built Angular app) ---------- */
function serveStatic(req, res, url) {
  let rel;
  try { rel = decodeURIComponent(url.pathname); } catch (e) { rel = '/'; }
  let file = path.normalize(path.join(DIST, rel));
  if (!file.startsWith(DIST)) { file = path.join(DIST, 'index.html'); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { file = path.join(DIST, 'index.html'); } // Angular routes
    fs.readFile(file, (err2, buf) => {
      if (err2) {
        res.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('The app is not built yet. Run "npm run build" first, then restart the server.');
        return;
      }
      const isIndex = path.basename(file) === 'index.html';
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
        'Cache-Control': isIndex ? 'no-cache' : 'public, max-age=31536000, immutable'
      });
      res.end(buf);
    });
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
    api(req, res, url).catch(e => {
      if (!res.headersSent) { fail(res, e.message === 'too large' ? 413 : 400, 'Request could not be read: ' + e.message); }
    });
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); res.end(); return; }
  serveStatic(req, res, url);
});

server.listen(PORT, HOST, () => {
  console.log('Deployment Tracker running on port ' + PORT);
  console.log('  This machine:  http://localhost:' + PORT);
  const nets = require('os').networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const n of nets[name] || []) {
      if (n.family === 'IPv4' && !n.internal) { console.log('  On the network: http://' + n.address + ':' + PORT); }
    }
  }
  console.log('  Data file:     ' + DATA_FILE);
});
