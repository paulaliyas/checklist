# Deployment Tracker

Angular 13 app with a dashboard for tracking stories and features from lower env to prod.
Everyone on the network sees the same status, because all data is saved on one small server.

## How it fits together

- `src/` is the Angular 13 app (NgModule, separate .html / .scss / .ts files).
- `server/server.js` is the shared server. It needs only Node.js, no npm packages.
  - Saves all items in `server/data/items.json`.
  - Reads checklist types from `server/templates/*.json`.
  - Pushes live updates to every open browser.
  - Serves the built app from `dist/deployment-tracker`.

## Run it for the team

On one machine that stays on and that others can reach:

```
node server/server.js
```

The app is already built in `dist/`, so this is the only command needed.
The console prints the address, for example `http://10.0.0.25:3000`. Share that address with the team.

- Change the port: `PORT=8080 node server/server.js` (Windows: `set PORT=8080` first).
- The machine's firewall must allow that port.
- Back up `server/data/items.json` to keep the history.

## Change the app

```
npm install
node server/server.js     # terminal 1: the API on port 3000
npm start                 # terminal 2: Angular dev server on http://localhost:4200
```

`npm start` forwards `/api` calls to port 3000 (see `proxy.conf.json`).
When done, run `npm run build` and restart the server.

Note: Angular 13 officially supports Node 12, 14 and 16 for `npm install` / `ng build`.
`server/server.js` itself runs on any Node from 12 up.

## Add a new checklist type

No Angular change is needed. Add one JSON file in `server/templates/` and reload the page.
Copy `story-deployment.json` and edit it:

```json
{
  "id": "db-script-release",
  "name": "DB script release",
  "targets": ["release", "hotfix"],
  "stages": [
    { "id": "review", "name": "Review" },
    { "id": "run", "name": "Run" }
  ],
  "steps": [
    { "id": "dba_review", "stage": "review", "title": "DBA review", "owner": "DBA", "refLabel": "Ticket no." },
    { "id": "mail_dba", "stage": "run", "title": "Mail DBA: run on {{target}}", "owner": "DBA",
      "mail": { "to": "DBA", "subject": "Run script: {{name}}", "body": "Ticket: {{ref:dba_review}}" } }
  ]
}
```

- `id` must be unique and should not change once items use it.
- `targets` is optional. It gives the choices for `{{target}}`.
- A step with `refLabel` shows a text field (MR link, build number...).
- A step with `mail` shows Copy and View buttons.
- Placeholders in titles and mails: `{{name}}`, `{{target}}`, `{{ref:stepId}}`.

With more than one type, the dashboard shows a type picker and a type filter.

## Good to know

- There is no login. "Your name" is typed once per browser and shown next to each tick.
  Anyone who can open the address can tick, edit and delete.
- Colours are in `src/styles.scss` under `:root`.
